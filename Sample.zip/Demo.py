import spacy
nlp = spacy.load("en_core_web_sm")
myString = "I eat Apple."
doc = nlp(myString)
for t in doc.ents:
    print(t.text)
    print(t.label_)
    print(str(spacy.explain(t.label_)))
