import spacy
nlp = spacy.load("en_core_web_sm")

from spacy import displacy
doc = nlp(u"Hi this is Srinivasan Jayakumar working in TCS.")

displacy.serve(doc, style='dep', options={'distance': 100})